import { writeFile } from "node:fs/promises";

const origin = (process.env.VITE_CANONICAL_ORIGIN || "").replace(/\/+$/, "");
const routes = [
  "/", "/calculators", "/about", "/contact", "/privacy", "/terms",
  "/disclaimer", "/accessibility", "/guides", "/blog", "/sitemap",
  "/category/finance", "/category/everyday", "/category/health",
  "/category/education", "/category/home", "/category/science", "/category/conversion",
  "/calculators/percentage", "/calculators/compound-interest",
  "/calculators/loan-emi", "/calculators/age", "/calculators/unit-converter",
  "/calculators/bmi", "/calculators/paint", "/calculators/ohms-law",
  "/calculators/profit-margin", "/calculators/simple-interest",
  "/calculators/roi", "/calculators/cagr", "/calculators/savings-growth",
  "/calculators/savings-goal", "/calculators/loan-amortization",
  "/calculators/dti", "/calculators/gpa-cgpa", "/calculators/final-grade",
  "/calculators/fraction", "/calculators/ratio",
];
const urls = origin
  ? routes.map((route) => `  <url><loc>${origin}${route}</loc></url>`).join("\n")
  : "  <!-- Set VITE_CANONICAL_ORIGIN at build time to emit absolute page URLs. -->";
const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
await writeFile(new URL("../public/sitemap.xml", import.meta.url), xml);
const robots = `User-agent: *\nAllow: /\n${origin ? `Sitemap: ${origin}/sitemap.xml\n` : ""}`;
await writeFile(new URL("../public/robots.txt", import.meta.url), robots);
