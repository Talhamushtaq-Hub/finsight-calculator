import { type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation, Router as WouterRouter } from "wouter";
import { CalculatorPage, CategoryPage, DirectoryPage, HomePage, InfoPage, NotFoundPage, Shell } from "./Site";

const queryClient = new QueryClient();
function RoutedErrorBoundary({children}:{children:ReactNode}) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function Router() {
 return <RoutedErrorBoundary><Shell><Switch>
  <Route path="/" component={HomePage}/>
  <Route path="/calculators" component={DirectoryPage}/>
  <Route path="/category/:slug" component={CategoryPage}/>
  <Route path="/calculators/:slug" component={CalculatorPage}/>
  <Route path="/about">{()=> <InfoPage type="about"/>}</Route>
  <Route path="/contact">{()=> <InfoPage type="contact"/>}</Route>
  <Route path="/privacy">{()=> <InfoPage type="privacy"/>}</Route>
  <Route path="/terms">{()=> <InfoPage type="terms"/>}</Route>
  <Route path="/disclaimer">{()=> <InfoPage type="disclaimer"/>}</Route>
  <Route path="/accessibility">{()=> <InfoPage type="accessibility"/>}</Route>
  <Route path="/guides">{()=> <InfoPage type="guides"/>}</Route>
   <Route path="/blog">{()=> <InfoPage type="guides"/>}</Route>
  <Route path="/sitemap">{()=> <InfoPage type="sitemap"/>}</Route>
  <Route component={NotFoundPage}/>
 </Switch></Shell></RoutedErrorBoundary>;
}
function App() {
 return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,"")}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>;
}
export default App;
