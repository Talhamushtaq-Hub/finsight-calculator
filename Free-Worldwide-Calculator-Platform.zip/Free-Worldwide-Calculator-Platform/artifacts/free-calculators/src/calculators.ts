export type CalcDef = {
  slug: string; title: string; short: string; category: string; icon: string; aliases: string[];
  intro: string; how: string[]; formula: string; variables: string[]; example: string; assumptions: string;
  faqs: { q: string; a: string }[]; fields: { name: string; label: string; value: string; unit?: string }[];
};

export const categories = ["Finance", "Everyday", "Education", "Health", "Home", "Science", "Conversion"];
export const calcs: CalcDef[] = [
 {slug:"percentage",title:"Percentage Calculator",short:"Work out a percentage, change, or proportion in seconds.",category:"Everyday",icon:"%",aliases:["percent","percentage change","percent of"],intro:"A quick, flexible way to answer the percentage questions that come up in everyday decisions. Calculate a part of a whole or compare two values as a percentage change.",how:["Choose the calculation you need.","Enter the known values in the fields.","Read the result; use Reset to start over or Copy result to reuse it."],formula:"Part = Whole × Rate ÷ 100 · Change % = (New − Original) ÷ Original × 100",variables:["Part: the amount represented by a percentage.","Whole: the reference amount.","Rate: percentage expressed from 0 to 100.","Original and New: values being compared."],example:"What is 15% of 240? Enter 15 and 240 to get 36.",assumptions:"Percentage change is undefined when the original value is zero. Negative values are accepted and retain their arithmetic meaning.",faqs:[{q:"How do I find a percentage of a number?",a:"Multiply the number by the percentage and divide by 100. For example, 15% of 240 is 36."},{q:"How is percentage change calculated?",a:"Subtract the original value from the new value, divide by the original, then multiply by 100."},{q:"Can a percentage change be negative?",a:"Yes. A negative result means the new value is lower than the original."},{q:"Why is change from zero unavailable?",a:"A percentage change needs a non-zero starting value as its reference."}],fields:[{name:"mode",label:"Calculation",value:"part",unit:"select:part,change"},{name:"rate",label:"Percentage",value:"15",unit:"%"},{name:"whole",label:"Number",value:"240"},{name:"original",label:"Original value",value:"100"},{name:"newValue",label:"New value",value:"125"}]},
 {slug:"compound-interest",title:"Compound Interest Calculator",short:"Estimate how a balance may grow as interest compounds.",category:"Finance",icon:"CI",aliases:["investment growth","compound return","savings"],intro:"Estimate the future value of a starting balance when interest is added regularly and then earns interest itself. The result is a mathematical projection, not a promised return.",how:["Enter the initial principal and annual interest rate.","Set the compounding frequency and time period.","Review the estimated balance and interest earned."],formula:"A = P × (1 + r ÷ n)^(n × t)",variables:["A: projected ending balance.","P: starting principal.","r: annual rate as a decimal.","n: compounding periods per year.","t: time in years."],example:"A principal of 1,000 at 5% compounded monthly for 2 years gives approximately 1,104.94 before fees or taxes.",assumptions:"Assumes a fixed nominal annual rate, fixed compounding schedule, no deposits, withdrawals, fees, or taxes. Actual returns can differ.",faqs:[{q:"What does compounding mean?",a:"Interest is added to the balance, so later interest can be earned on both the original amount and previously credited interest."},{q:"Does this include regular contributions?",a:"No. This version models one initial principal without additional deposits."},{q:"Is the result guaranteed?",a:"No. It is a mathematical estimate based on the rate and schedule you enter."},{q:"What is compounding frequency?",a:"It is how often interest is added to the balance, such as monthly or annually."}],fields:[{name:"principal",label:"Starting principal",value:"1000",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"5",unit:"%"},{name:"years",label:"Time period",value:"2",unit:"years"},{name:"frequency",label:"Compounds per year",value:"12",unit:"select:1,2,4,12,365"}]},
 {slug:"loan-emi",title:"Loan EMI Calculator",short:"Estimate a fixed monthly payment for a reducing-balance loan.",category:"Finance",icon:"EMI",aliases:["loan payment","monthly installment","mortgage payment"],intro:"Estimate the equal monthly installment for a loan with a fixed annual interest rate and term. This is a planning aid; a lender's schedule may include fees and different conventions.",how:["Enter the amount borrowed, annual rate, and repayment term in years.","Review the estimated monthly installment and total interest.","Compare scenarios by adjusting one input at a time."],formula:"EMI = P × i × (1 + i)^N ÷ ((1 + i)^N − 1)",variables:["P: principal borrowed.","i: monthly interest rate (annual rate ÷ 12 ÷ 100).","N: total number of monthly payments."],example:"A 10,000 loan at 6% annually for 3 years has an estimated payment of about 304.22 per month.",assumptions:"Assumes monthly payments, a fixed rate, and a standard amortizing loan. Excludes fees, insurance, taxes, and lender-specific rounding.",faqs:[{q:"What does EMI mean?",a:"EMI is an equated monthly installment: a regular payment that combines interest and principal."},{q:"Can the payment be estimated at zero interest?",a:"Yes. At 0% interest, the principal is divided evenly across the monthly payments."},{q:"Does the estimate include fees?",a:"No. Origination charges, insurance, taxes, and other lender charges are not included."},{q:"Why might my lender's amount differ?",a:"Payment timing, day-count methods, fees, rounding, and rate changes can alter an actual schedule."}],fields:[{name:"principal",label:"Loan amount",value:"10000",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"6",unit:"%"},{name:"years",label:"Loan term",value:"3",unit:"years"}]},
 {slug:"age",title:"Age Calculator",short:"Find the elapsed time between a birth date and a chosen date.",category:"Everyday",icon:"AGE",aliases:["date of birth","birthday","years old"],intro:"Calculate age in completed years, months, and days between two calendar dates. Choose a reference date to check an age on a past or future day.",how:["Choose the date of birth.","Optionally set the date to calculate age on; today is used by default.","Read the elapsed calendar age."],formula:"Elapsed calendar time = reference date − birth date",variables:["Birth date: starting calendar day.","Reference date: ending calendar day; defaults to today."],example:"From 15 March 2000 to 15 March 2024 is 24 years, 0 months, and 0 days.",assumptions:"Uses local calendar dates and completed calendar units, not time-of-day. A reference date before birth is invalid.",faqs:[{q:"Does the calculator use today's date?",a:"Yes, unless you enter a different reference date."},{q:"How are leap days handled?",a:"The calculation compares calendar dates; leap days count as calendar days in the elapsed period."},{q:"Can I calculate age on a past date?",a:"Yes. Enter that date in the reference date field."},{q:"Does it calculate time of birth?",a:"No. It compares dates only and does not use hours or time zones."}],fields:[{name:"birth",label:"Date of birth",value:"2000-03-15",unit:"date"},{name:"at",label:"Age on date",value:new Date().toISOString().slice(0,10),unit:"date"}]},
  {slug:"unit-converter",title:"Unit Converter",short:"Convert common length, mass, area, volume, speed, time, data, and temperature units.",category:"Conversion",icon:"↔",aliases:["length converter","mass converter","temperature converter","area converter","volume converter","speed converter","time converter","data storage converter","feet to meters","metric","imperial"],intro:"Convert everyday measurements between common metric, imperial, and data-storage units. Select a measurement type and source and destination units; exchange rates are not included.",how:["Choose a measurement type such as length, area, or temperature.","Select the starting and destination units.","Enter a value to see the converted measurement."],formula:"For length, mass, area, volume, speed, time, and data, convert through a defined base unit. Temperature: °F = °C × 9/5 + 32; K = °C + 273.15.",variables:["Value: measurement to convert.","From / To: source and destination units.","Base unit depends on the selected measurement type."],example:"2.5 kilometres converts to 2,500 metres. 20°C converts to 68°F. One US gallon is about 0.8327 Imperial gallons.",assumptions:"Uses standard unit definitions, distinguishes US and Imperial gallons, and distinguishes decimal (KB) from binary (KiB) data units. Results are rounded to up to 6 decimal places.",faqs:[{q:"Which measurement types are included?",a:"Length, mass, area, volume, speed, time, data storage, and temperature."},{q:"Are US and Imperial gallons the same?",a:"No. The calculator uses distinct conversion factors for US gallons and Imperial gallons."},{q:"What is the difference between KB and KiB?",a:"KB uses a decimal factor of 1,000 bytes; KiB uses a binary factor of 1,024 bytes."},{q:"Does this convert currencies?",a:"No. Currency conversion needs a reliable exchange-rate source and timestamp, which are not provided by this unit-only tool."}],fields:[{name:"value",label:"Value",value:"2.5"},{name:"kind",label:"Measurement",value:"length",unit:"select:length,mass,area,volume,speed,time,data,temperature"},{name:"from",label:"From",value:"km",unit:"select:mm,cm,m,km,in,ft,mi"},{name:"to",label:"To",value:"m",unit:"select:mm,cm,m,km,in,ft,mi"}]},
 {slug:"bmi",title:"BMI Calculator",short:"Calculate body mass index from height and weight.",category:"Health",icon:"BMI",aliases:["body mass index","healthy weight"],intro:"Calculate body mass index from a person's height and weight using metric measurements. BMI is a screening measure and cannot assess health on its own.",how:["Enter weight in kilograms.","Enter height in centimetres.","Review the BMI value and broad adult reference range."],formula:"BMI = weight (kg) ÷ height (m)²",variables:["Weight: body mass in kilograms.","Height: stature in metres; centimetres are converted automatically."],example:"A weight of 70 kg at 1.75 m gives a BMI of 22.9.",assumptions:"The displayed adult categories are general population screening ranges. BMI does not distinguish muscle from fat or account for age, pregnancy, or individual health context.",faqs:[{q:"What is BMI?",a:"BMI is weight divided by height squared, a screening measure used for broad population comparisons."},{q:"Is BMI a diagnosis?",a:"No. It cannot diagnose health or describe body composition; speak with a qualified health professional for personal advice."},{q:"What units should I enter?",a:"This calculator accepts kilograms and centimetres."},{q:"Do adult ranges apply to children?",a:"No. Children and teens require age- and sex-specific percentile interpretation."}],fields:[{name:"weight",label:"Weight",value:"70",unit:"kg"},{name:"height",label:"Height",value:"175",unit:"cm"}]},
 {slug:"paint",title:"Paint Calculator",short:"Estimate paint volume from wall dimensions and coverage.",category:"Home",icon:"PT",aliases:["paint coverage","wall paint","litres of paint"],intro:"Estimate how much paint a set of rectangular walls may need. Add the wall dimensions, number of coats, and the coverage printed on your paint container.",how:["Enter wall width and height in metres.","Choose the number of coats and coverage per litre.","Subtract optional area for openings such as doors and windows."],formula:"Paint (L) = max(0, total wall area − openings) × coats ÷ coverage per litre",variables:["Area: width × height for each wall.","Coats: number of paint layers.","Coverage: square metres per litre stated by the manufacturer.","Openings: area not being painted."],example:"Four 4 m × 2.5 m walls total 40 m². At 10 m²/L for two coats, estimate 8 L before subtracting openings.",assumptions:"Assumes rectangular surfaces and the stated coverage rate. Surface texture, application method, primer, waste, and product-specific recommendations can change actual use.",faqs:[{q:"What does coverage per litre mean?",a:"It is the area a litre is expected to cover, as stated on the paint product."},{q:"Can I account for windows and doors?",a:"Yes. Enter their combined area to subtract it from the wall area."},{q:"Should I add extra paint?",a:"Consider surface condition, touch-ups, and the manufacturer's guidance; the estimate does not add a waste allowance."},{q:"Does this include ceilings?",a:"The fields model repeated rectangular wall sections. Add ceiling area separately as another surface if needed."}],fields:[{name:"width",label:"Width per wall",value:"4",unit:"m"},{name:"height",label:"Wall height",value:"2.5",unit:"m"},{name:"walls",label:"Number of walls",value:"4"},{name:"coats",label:"Number of coats",value:"2"},{name:"coverage",label:"Coverage per litre",value:"10",unit:"m²/L"},{name:"openings",label:"Openings area (optional)",value:"0",unit:"m²"}]},
 {slug:"ohms-law",title:"Ohm's Law Calculator",short:"Solve voltage, current, resistance, or power from known values.",category:"Science",icon:"Ω",aliases:["voltage","current","resistance","electrical"],intro:"Use Ohm's law to solve a basic circuit quantity when two suitable values are known. The tool calculates voltage, current, resistance, and power for an ideal DC relationship.",how:["Choose the two known quantities and enter their values.","Select the matching units.","Read the solved voltage, current, resistance, and power."],formula:"V = I × R · P = V × I",variables:["V: voltage in volts.","I: current in amperes.","R: resistance in ohms.","P: power in watts."],example:"With 12 V across 6 Ω, current is 2 A and power is 24 W.",assumptions:"Applies to a simple resistive DC model. AC phase, reactive components, temperature effects, and circuit safety are outside this calculation.",faqs:[{q:"What is Ohm's law?",a:"For an ideal resistor, voltage equals current multiplied by resistance."},{q:"Can I solve all four values?",a:"This calculator asks for voltage and resistance and derives current and power."},{q:"Does it apply to AC circuits?",a:"Not fully. AC circuits with phase or reactance need additional electrical analysis."},{q:"Is this a safety assessment?",a:"No. It is a basic mathematical aid, not guidance for working on live electrical systems."}],fields:[{name:"voltage",label:"Voltage",value:"12",unit:"V"},{name:"resistance",label:"Resistance",value:"6",unit:"Ω"}]},
  {slug:"profit-margin",title:"Profit Margin Calculator",short:"Find gross profit and margin from revenue and cost.",category:"Finance",icon:"PM",aliases:["gross margin","markup","profit percentage"],intro:"See the difference between profit margin and markup using revenue and cost. The margin is expressed as a share of revenue, which makes it useful for comparing sales.",how:["Enter sales revenue and the associated cost.","Review the gross profit and margin percentage.","Use Reset to compare another scenario."],formula:"Gross profit = Revenue − Cost · Margin % = Gross profit ÷ Revenue × 100",variables:["Revenue: selling income before costs entered here.","Cost: associated cost of goods or service.","Margin: profit as a proportion of revenue."],example:"Revenue of 80 and cost of 50 gives 30 gross profit and a 37.5% margin.",assumptions:"Treats the entered cost as the only cost. Excludes taxes, operating expenses, payment fees, and other overhead.",faqs:[{q:"What is profit margin?",a:"Profit margin expresses profit as a percentage of revenue."},{q:"How is margin different from markup?",a:"Margin divides profit by revenue; markup divides profit by cost."},{q:"Can the result be negative?",a:"Yes. If cost exceeds revenue, the result indicates a loss and negative margin."},{q:"Does this include tax or overhead?",a:"No. Add any costs you want included to the cost input; this is not accounting advice."}],fields:[{name:"revenue",label:"Revenue",value:"80",unit:"currency"},{name:"cost",label:"Cost",value:"50",unit:"currency"}]},
  {slug:"simple-interest",title:"Simple Interest Calculator",short:"Estimate interest that is calculated only on the original principal.",category:"Finance",icon:"SI",aliases:["simple interest formula","interest earned","simple interest rate"],intro:"Estimate interest on a principal when interest does not compound. Enter the annual rate and time period to see interest earned and the ending balance.",how:["Enter the starting principal, annual interest rate, and duration in years.","Review the interest amount and total balance.","Use the same currency unit for all money values; no currency conversion is performed."],formula:"I = P × r × t · A = P + I",variables:["I: simple interest earned.","P: starting principal.","r: annual interest rate as a decimal.","t: time in years.","A: principal plus interest."],example:"A principal of 5,000 at 4% per year for 3 years earns 600 interest and ends at 5,600.",assumptions:"Assumes a constant annual rate and simple, non-compounding interest. Day-count rules, fees, and taxes are excluded.",faqs:[{q:"How is simple interest different from compound interest?",a:"Simple interest is calculated only on the original principal; compound interest can also earn interest on previously credited interest."},{q:"Does the rate need to be entered as a decimal?",a:"No. Enter a percentage such as 4 for 4%; the calculator converts it in the formula."},{q:"Can I enter months?",a:"Enter the period as a fraction of a year, such as 0.5 for six months."},{q:"Does this include fees or tax?",a:"No. The result is a mathematical estimate before fees or taxes."}],fields:[{name:"principal",label:"Starting principal",value:"5000",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"4",unit:"%"},{name:"years",label:"Time period",value:"3",unit:"years"}]},
  {slug:"roi",title:"Return on Investment Calculator",short:"Compare an investment's gain or loss with its original cost.",category:"Finance",icon:"ROI",aliases:["investment return","return on investment","ROI percentage"],intro:"Calculate a simple return on investment from the amount invested and its ending value. This percentage does not account for the time held, inflation, fees, or taxes.",how:["Enter the original investment cost and current or ending value.","Use the same currency for both amounts.","Review the net gain or loss and ROI percentage."],formula:"ROI % = (Ending value − Investment cost) ÷ Investment cost × 100",variables:["Investment cost: original amount invested.","Ending value: value at the comparison date.","Net gain/loss: ending value minus investment cost."],example:"An investment costing 1,000 and later worth 1,300 has a 300 gain and a 30% ROI.",assumptions:"A simple, non-annualized comparison. It excludes cash flows, fees, taxes, and the time value of money.",faqs:[{q:"Can ROI be negative?",a:"Yes. If the ending value is below the original cost, ROI is negative."},{q:"Does ROI account for how long I held an investment?",a:"No. ROI is not annualized; use CAGR for a time-adjusted growth rate when its assumptions fit."},{q:"Should I include fees?",a:"For a net-of-fee estimate, include fees in the investment cost or subtract them from the ending value."},{q:"Is ROI a forecast?",a:"No. It compares values you provide and does not predict future performance."}],fields:[{name:"cost",label:"Investment cost",value:"1000",unit:"currency"},{name:"ending",label:"Ending value",value:"1300",unit:"currency"}]},
  {slug:"cagr",title:"CAGR Calculator",short:"Calculate the annualized growth rate between two positive values.",category:"Finance",icon:"CAGR",aliases:["annualized return","compound annual growth rate","investment growth rate"],intro:"Calculate the compound annual growth rate between a starting and ending value over a stated number of years. CAGR smooths the path into one rate; it does not show volatility along the way.",how:["Enter a positive starting value and ending value.","Enter the elapsed period in years.","Review the annualized rate and total change."],formula:"CAGR = (Ending value ÷ Starting value)^(1 ÷ years) − 1",variables:["Starting value: value at the beginning of the period.","Ending value: value at the end of the period.","Years: elapsed time in years."],example:"A value growing from 1,000 to 1,331 over 3 years has a CAGR of 10% per year.",assumptions:"Requires positive start and end values and a positive duration. Assumes a smoothed compound rate and does not imply steady yearly returns.",faqs:[{q:"What does CAGR mean?",a:"Compound annual growth rate is the constant yearly rate that would connect a starting value to an ending value over the period."},{q:"Does CAGR show the actual return each year?",a:"No. It smooths the overall change and hides fluctuations between the start and end."},{q:"Can CAGR be negative?",a:"Yes. A positive ending value below the starting value produces a negative CAGR."},{q:"Does this include deposits or withdrawals?",a:"No. Cash flows during the period make this simple CAGR formula unsuitable without adjustment."}],fields:[{name:"start",label:"Starting value",value:"1000",unit:"currency"},{name:"ending",label:"Ending value",value:"1331",unit:"currency"},{name:"years",label:"Time period",value:"3",unit:"years"}]},
  {slug:"savings-growth",title:"Savings Growth Calculator",short:"Estimate savings growth with a starting balance and monthly deposits.",category:"Finance",icon:"SG",aliases:["savings calculator","monthly savings growth","future value of deposits"],intro:"Project a savings balance when you start with an amount and add the same deposit at the end of each month. The estimate uses a fixed annual rate and is not a guaranteed return.",how:["Enter your current balance and planned monthly deposit.","Add an annual rate assumption and time period.","Review the projected balance, deposits, and estimated growth."],formula:"FV = P(1 + i)^N + M × (((1 + i)^N − 1) ÷ i); if i = 0, FV = P + MN",variables:["FV: projected future balance.","P: starting balance.","M: deposit made at the end of each month.","i: annual rate ÷ 12 ÷ 100.","N: number of monthly periods; years are converted to the nearest month."],example:"With a 1,000 starting balance, 100 deposited monthly, a 5% annual rate, and 2 years, the ending estimate is about 3,623.53.",assumptions:"Assumes end-of-month deposits, a fixed nominal annual rate divided monthly, and no fees, taxes, or missed deposits. Actual savings products may use different compounding conventions.",faqs:[{q:"When are monthly deposits assumed to happen?",a:"Deposits are assumed to be made at the end of each month."},{q:"Is the annual rate guaranteed?",a:"No. It is an input assumption; actual rates and returns can change."},{q:"Does this include fees or tax?",a:"No. The projection is before fees and taxes."},{q:"What happens at a zero rate?",a:"The result is the starting balance plus all monthly deposits, with no interest added."}],fields:[{name:"principal",label:"Starting balance",value:"1000",unit:"currency"},{name:"monthly",label:"Monthly deposit",value:"100",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"5",unit:"%"},{name:"years",label:"Time period",value:"2",unit:"years"}]},
  {slug:"savings-goal",title:"Savings Goal Calculator",short:"Estimate the monthly deposit needed to reach a savings target.",category:"Finance",icon:"SG",aliases:["monthly savings goal","how much to save each month","goal savings"],intro:"Estimate a monthly deposit to reach a target balance from your current savings. The estimate can include an assumed annual return but does not guarantee a savings outcome.",how:["Enter your target and current balance.","Choose an annual rate assumption and the number of years to save.","Review the required end-of-month deposit; if the current balance is already projected to exceed the target, the deposit is zero."],formula:"If i ≠ 0: M = max(0, (G − P(1+i)^N) × i ÷ ((1+i)^N − 1)); if i = 0: M = max(0, (G − P) ÷ N)",variables:["M: required monthly deposit.","G: target balance.","P: current balance.","i: monthly rate (annual rate ÷ 12 ÷ 100).","N: number of monthly periods; years are converted to the nearest month."],example:"With a 10,000 target, 2,000 saved, 5% annual growth, and 3 years, the required monthly deposit is about 198.10.",assumptions:"Assumes end-of-month deposits, a fixed nominal annual rate compounded monthly, and no fees, taxes, or withdrawals. The time period is converted to the nearest month; rates and results are estimates.",faqs:[{q:"What if I already have enough saved?",a:"If the current balance is at or above the target, the calculator reports zero required monthly deposits."},{q:"When are deposits assumed to happen?",a:"The estimate assumes deposits arrive at the end of each month."},{q:"Can I use a zero interest rate?",a:"Yes. The calculator divides the remaining goal by the number of months."},{q:"Is this a guarantee that I will reach the goal?",a:"No. Actual rates, timing, and account fees may differ from your inputs."}],fields:[{name:"goal",label:"Savings target",value:"10000",unit:"currency"},{name:"principal",label:"Current balance",value:"2000",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"5",unit:"%"},{name:"years",label:"Time to save",value:"3",unit:"years"}]},
  {slug:"loan-amortization",title:"Loan Amortization Calculator",short:"Estimate a fixed monthly payment and view the principal-interest schedule.",category:"Finance",icon:"AM",aliases:["amortization schedule","loan schedule","monthly principal and interest"],intro:"Estimate payments for a fixed-rate amortizing loan and inspect how each scheduled payment is divided between interest and principal. Lender fees and non-monthly payment rules are not included.",how:["Enter the amount borrowed, annual rate, and term in years.","Review the estimated monthly payment and total interest.","Expand the schedule to inspect each month's interest, principal, and remaining balance."],formula:"Payment = P × i × (1+i)^N ÷ ((1+i)^N − 1); monthly interest = opening balance × i",variables:["P: original principal.","i: annual rate ÷ 12 ÷ 100.","N: number of monthly payments.","Principal portion: payment minus that month's interest."],example:"A 10,000 loan at 6% per year for 3 years has a monthly payment of about 304.22 and 951.92 total interest before fees.",assumptions:"Assumes fixed monthly payments on a reducing balance. Excludes fees, insurance, taxes, extra payments, rate changes, and lender-specific day-count rules. Schedule is limited to 50 years.",faqs:[{q:"What does an amortization schedule show?",a:"It shows each payment's interest and principal portions and the remaining balance after payment."},{q:"Why does the interest portion change?",a:"With a reducing balance, the interest portion generally falls as principal is repaid."},{q:"Does the schedule include extra payments?",a:"No. It models the standard scheduled payment only."},{q:"Why might a lender's schedule differ?",a:"Fees, payment dates, rounding, compounding conventions, and variable rates can change actual amounts."}],fields:[{name:"principal",label:"Loan amount",value:"10000",unit:"currency"},{name:"rate",label:"Annual interest rate",value:"6",unit:"%"},{name:"years",label:"Loan term",value:"3",unit:"years"}]},
  {slug:"dti",title:"Debt-to-Income Ratio Calculator",short:"Compare monthly debt payments with gross monthly income.",category:"Finance",icon:"DTI",aliases:["DTI calculator","debt to income","monthly debt ratio"],intro:"Calculate monthly debt-to-income ratio by comparing recurring monthly debt payments with gross monthly income before tax. Lenders may count debts and income differently.",how:["Enter recurring monthly debt payments.","Enter gross monthly income before tax.","Review the ratio as a percentage; use the same currency units for both amounts."],formula:"DTI % = Monthly debt payments ÷ Gross monthly income × 100",variables:["Monthly debt payments: recurring debt obligations included in your estimate.","Gross monthly income: income before taxes and deductions."],example:"Monthly debts of 1,500 and gross monthly income of 5,000 produce a 30% DTI.",assumptions:"This is a simple ratio, not a lender approval test. It does not define which debts a lender includes or account for household expenses.",faqs:[{q:"What does DTI measure?",a:"It compares monthly debt payments with gross monthly income."},{q:"Should I use take-home pay?",a:"This calculator uses gross income before taxes, as specified in its formula."},{q:"Which debts should I include?",a:"Enter the recurring debt payments relevant to your estimate; lender definitions can differ."},{q:"Does a specific DTI guarantee loan approval?",a:"No. Lenders use additional criteria and may calculate the ratio differently."}],fields:[{name:"debt",label:"Monthly debt payments",value:"1500",unit:"currency"},{name:"income",label:"Gross monthly income",value:"5000",unit:"currency"}]},
  {slug:"gpa-cgpa",title:"GPA & CGPA Calculator",short:"Calculate a credit-weighted GPA from grade points and course credits.",category:"Education",icon:"GPA",aliases:["GPA calculator","CGPA calculator","cumulative GPA","grade point average"],intro:"Calculate a credit-weighted grade point average from course grade points and credit hours. Enter each course as a comma-separated value and choose the maximum points on your grading scale.",how:["Choose the maximum grade-point value used by your institution.","Enter one numeric grade point per course, separated by commas.","Enter the matching credit hours in the same order, then compare the number of entries."],formula:"GPA or CGPA = Σ(grade points × course credits) ÷ Σ(course credits)",variables:["Grade points: each course's numeric result on the selected scale.","Course credits: credit hours associated with each grade.","Scale maximum: institution's maximum grade-point value."],example:"Grades 4.0 and 3.0 with 3 credits each give (4×3 + 3×3) ÷ 6 = 3.50 on a 4-point scale.",assumptions:"Uses the numeric grade points and credits supplied by you. Institutions may treat repeats, withdrawals, pass/fail courses, and rounding differently; this is not a universal conversion between grading systems.",faqs:[{q:"Can I use this as a GPA or CGPA calculator?",a:"Yes. Enter the courses for one term for a GPA, or all included courses to estimate a cumulative GPA/CGPA."},{q:"Does every institution use the same grading scale?",a:"No. Select the scale maximum and enter grade points exactly as your institution defines them."},{q:"Do credits affect the result?",a:"Yes. Each course grade is weighted by its credit hours."},{q:"Can I enter letter grades?",a:"This version accepts numeric grade points. Convert letters using your institution's official scale before entering them."}],fields:[{name:"scale",label:"Maximum grade points",value:"4",unit:"select:4,5,10,100"},{name:"grades",label:"Course grade points (comma-separated)",value:"4,3",unit:"text"},{name:"credits",label:"Course credits (comma-separated)",value:"3,3",unit:"text"}]},
  {slug:"final-grade",title:"Final Grade Calculator",short:"Find the exam score needed to reach a target course grade.",category:"Education",icon:"FG",aliases:["required exam score","final exam grade","what grade do I need"],intro:"Estimate the percentage needed on a final exam to reach a target course grade, based on your current grade and the exam's share of the overall grade.",how:["Enter your current course grade as a percentage before the final.","Enter the final exam's percentage weight in the course.","Enter your desired overall grade and review the required exam score."],formula:"Required exam % = (Target course % − Current grade % × (1 − exam weight)) ÷ exam weight",variables:["Current grade: weighted course percentage before the final exam.","Exam weight: final exam share of total grade, entered as a percentage.","Target: desired overall course percentage."],example:"With an 82% current grade, a final worth 40% of the course, and an 85% target, the required final score is 89.5%.",assumptions:"Assumes the current grade represents all non-final work and the entered exam weight is its share of the final course grade. Rounding and grading policies vary by institution.",faqs:[{q:"What does a result over 100% mean?",a:"It means the target cannot be reached through the final exam alone under the entered assumptions."},{q:"What if I want to calculate my final grade instead?",a:"Use the current grade, exam score, and exam weight in the same weighted-average relationship; this tool focuses on the required score."},{q:"Should I enter the exam weight as 40 or 0.40?",a:"Enter 40 for an exam worth 40% of the course."},{q:"Does this account for extra credit?",a:"No. It assumes the weights and scores you enter are the complete grading model."}],fields:[{name:"current",label:"Current course grade",value:"82",unit:"%"},{name:"weight",label:"Final exam weight",value:"40",unit:"%"},{name:"target",label:"Target course grade",value:"85",unit:"%"}]},
  {slug:"fraction",title:"Fraction Calculator",short:"Add, subtract, multiply, or divide two fractions and simplify the result.",category:"Everyday",icon:"½",aliases:["fraction math","fraction addition","fraction simplifier"],intro:"Perform one arithmetic operation on two fractions and reduce the result to lowest terms. Denominators must be non-zero integers.",how:["Enter the numerator and denominator of each fraction.","Choose addition, subtraction, multiplication, or division.","Review the simplified fraction and decimal equivalent."],formula:"Add/subtract: a/b ± c/d = (ad ± bc)/bd · Multiply: ac/bd · Divide: ad/bc",variables:["a and c: numerators.","b and d: non-zero denominators.","Result is reduced by dividing numerator and denominator by their greatest common divisor."],example:"1/2 + 1/3 = (3 + 2)/6 = 5/6.",assumptions:"Inputs are integers. Fractions are simplified exactly before a decimal equivalent is displayed.",faqs:[{q:"Can I enter negative fractions?",a:"Yes. Numerators may be negative; denominators must be non-zero integers."},{q:"What happens when dividing fractions?",a:"The first fraction is multiplied by the reciprocal of the second; a zero second numerator is not allowed."},{q:"Why is the answer reduced?",a:"The numerator and denominator are divided by their greatest common divisor."},{q:"Is the decimal exact?",a:"The decimal display is rounded; the simplified fraction is the exact result."}],fields:[{name:"a",label:"First numerator",value:"1"},{name:"b",label:"First denominator",value:"2"},{name:"c",label:"Second numerator",value:"1"},{name:"d",label:"Second denominator",value:"3"},{name:"operation",label:"Operation",value:"add",unit:"select:add,subtract,multiply,divide"}]},
  {slug:"ratio",title:"Ratio Calculator",short:"Simplify a ratio of two whole numbers to its lowest terms.",category:"Everyday",icon:"A:B",aliases:["simplify ratio","ratio simplifier","ratio calculator"],intro:"Reduce a positive whole-number ratio to its simplest equivalent form. This calculator does not solve multi-part proportions or ratios with decimal inputs.",how:["Enter the two positive whole-number parts of the ratio.","Review the reduced ratio.","Check that both values use the same unit or basis before comparing them."],formula:"Simplified ratio = (a ÷ gcd(a,b)) : (b ÷ gcd(a,b))",variables:["a and b: positive whole-number parts of the ratio.","gcd(a,b): greatest common divisor of both parts."],example:"A ratio of 18:24 simplifies by dividing both parts by 6, giving 3:4.",assumptions:"Accepts positive integers only. Both quantities should use the same units or be comparable parts.",faqs:[{q:"How is a ratio simplified?",a:"Divide each part by the greatest common divisor shared by all parts."},{q:"Can I enter decimals?",a:"No. This version accepts positive whole numbers."},{q:"Does a simplified ratio change the underlying comparison?",a:"No. Multiplying or dividing both parts by the same non-zero factor preserves the ratio."},{q:"Can this solve a proportion?",a:"No. It simplifies two-part ratios only."}],fields:[{name:"a",label:"First quantity",value:"18"},{name:"b",label:"Second quantity",value:"24"}]}
];

export type CalculationResult = {
  value: string;
  detail: string;
  rows?: [string, string][];
  table?: { caption: string; headers: string[]; rows: string[][] };
};

const format = (value: number, digits = 2) =>
  Number.isFinite(value) ? value.toLocaleString(undefined, { maximumFractionDigits: digits }) : "—";

const unitFactors: Record<string, Record<string, number>> = {
  length: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, mi: 1609.344 },
  mass: { mg: 0.000001, g: 0.001, kg: 1, oz: 0.028349523125, lb: 0.45359237 },
  area: { "mm²": 0.000001, "cm²": 0.0001, "m²": 1, ha: 10000, "km²": 1000000, "ft²": 0.09290304, "yd²": 0.83612736, acre: 4046.8564224 },
  volume: { mL: 0.000001, L: 0.001, "cm³": 0.000001, "m³": 1, "US gal": 0.003785411784, "Imp gal": 0.00454609, "US fl oz": 0.0000295735295625, "US cup": 0.0002365882365 },
  speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704, knot: 0.514444444444 },
  time: { ms: 0.001, s: 1, min: 60, h: 3600, day: 86400, week: 604800 },
  data: { bit: 0.125, B: 1, KB: 1000, MB: 1000000, GB: 1000000000, TB: 1000000000000, KiB: 1024, MiB: 1048576, GiB: 1073741824, TiB: 1099511627776 },
};

function greatestCommonDivisor(a: bigint, b: bigint): bigint {
  let left = a < 0n ? -a : a;
  let right = b < 0n ? -b : b;
  while (right !== 0n) [left, right] = [right, left % right];
  return left;
}

function simplifiedFraction(numerator: bigint, denominator: bigint): string {
  if (denominator < 0n) {
    numerator = -numerator;
    denominator = -denominator;
  }
  const divisor = greatestCommonDivisor(numerator, denominator);
  const top = numerator / (divisor || 1n);
  const bottom = denominator / (divisor || 1n);
  return bottom === 1n ? String(top) : `${top}/${bottom}`;
}

function loanPayment(principal: number, annualRate: number, months: number): number {
  const monthlyRate = annualRate / 1200;
  if (monthlyRate === 0) return principal / months;
  const factor = Math.pow(1 + monthlyRate, months);
  return principal * monthlyRate * factor / (factor - 1);
}

export function calculate(slug: string, v: Record<string, string>): CalculationResult {
  const n = (key: string) => Number(v[key]);
  switch (slug) {
    case "percentage": {
      if (v.mode === "change") {
        const difference = n("newValue") - n("original");
        return {
          value: `${format(difference / n("original") * 100, 4)}%`,
          detail: "Percentage change from the original value.",
          rows: [["Difference", format(difference, 6)], ["Original value", format(n("original"), 6)], ["New value", format(n("newValue"), 6)]],
        };
      }
      const part = n("rate") * n("whole") / 100;
      return { value: format(part, 6), detail: `${v.rate || 0}% of ${format(n("whole"), 6)}`, rows: [["Calculation", "percentage × number ÷ 100"]] };
    }
    case "compound-interest": {
      const principal = n("principal");
      const rate = n("rate") / 100;
      const periods = n("frequency") * n("years");
      const amount = principal * Math.pow(1 + rate / n("frequency"), periods);
      return { value: format(amount), detail: "Estimated balance at the end of the selected period.", rows: [["Starting principal", format(principal)], ["Estimated interest", format(amount - principal)], ["Compounding periods", format(periods, 0)]] };
    }
    case "simple-interest": {
      const principal = n("principal");
      const interest = principal * n("rate") / 100 * n("years");
      return { value: format(interest), detail: "Simple interest earned, before fees or taxes.", rows: [["Total balance", format(principal + interest)], ["Starting principal", format(principal)], ["Interest earned", format(interest)]] };
    }
    case "roi": {
      const gain = n("ending") - n("cost");
      return { value: `${format(gain / n("cost") * 100)}%`, detail: "Simple return on the original investment cost.", rows: [["Net gain or loss", format(gain)], ["Investment cost", format(n("cost"))], ["Ending value", format(n("ending"))]] };
    }
    case "cagr": {
      const rate = Math.pow(n("ending") / n("start"), 1 / n("years")) - 1;
      return { value: `${format(rate * 100, 4)}% per year`, detail: "Compound annual growth rate; it smooths the period into one rate.", rows: [["Total change", `${format((n("ending") / n("start") - 1) * 100)}%`], ["Starting value", format(n("start"))], ["Ending value", format(n("ending"))]] };
    }
    case "savings-growth": {
      const principal = n("principal");
      const monthly = n("monthly");
      const monthlyRate = n("rate") / 1200;
      const periods = Math.round(n("years") * 12);
      const growthFactor = Math.pow(1 + monthlyRate, periods);
      const future = monthlyRate === 0
        ? principal + monthly * periods
        : principal * growthFactor + monthly * (growthFactor - 1) / monthlyRate;
      const deposits = principal + monthly * periods;
      return { value: format(future), detail: "Estimated balance with end-of-month deposits.", rows: [["Starting balance and deposits", format(deposits)], ["Estimated interest", format(future - deposits)], ["Number of deposits", format(periods, 0)]] };
    }
    case "savings-goal": {
      const goal = n("goal");
      const principal = n("principal");
      const monthlyRate = n("rate") / 1200;
      const periods = Math.round(n("years") * 12);
      const growthFactor = Math.pow(1 + monthlyRate, periods);
      const projectedCurrent = principal * growthFactor;
      const monthly = projectedCurrent >= goal
        ? 0
        : monthlyRate === 0
          ? (goal - principal) / periods
          : (goal - projectedCurrent) * monthlyRate / (growthFactor - 1);
      return { value: `${format(Math.max(0, monthly))} per month`, detail: "Estimated end-of-month deposit needed to reach the target.", rows: [["Target balance", format(goal)], ["Projected current balance", format(projectedCurrent)], ["Saving period", `${format(periods, 0)} months`]] };
    }
    case "loan-emi":
    case "loan-amortization": {
      const principal = n("principal");
      const months = Math.round(n("years") * 12);
      if (!Number.isFinite(months) || months < 1 || (slug === "loan-amortization" && months > 600)) {
        return { value: "—", detail: "Enter a loan term that fits the supported amortization schedule." };
      }
      const payment = loanPayment(principal, n("rate"), months);
      const total = payment * months;
      const rows: [string, string][] = [["Total of payments", format(total)], ["Estimated interest", format(total - principal)], ["Number of payments", format(months, 0)]];
      if (slug === "loan-emi") return { value: format(payment), detail: "Estimated monthly payment", rows };
      const monthlyRate = n("rate") / 1200;
      let balance = principal;
      const schedule = Array.from({ length: months }, (_, index) => {
        const interest = balance * monthlyRate;
        const principalPaid = Math.min(balance, payment - interest);
        balance = Math.max(0, balance - principalPaid);
        return [String(index + 1), format(payment), format(principalPaid), format(interest), format(balance)];
      });
      return {
        value: format(payment),
        detail: "Estimated monthly payment; expand the table for the full schedule.",
        rows,
        table: { caption: "Estimated monthly amortization schedule", headers: ["Payment", "Payment amount", "Principal", "Interest", "Balance"], rows: schedule },
      };
    }
    case "dti": {
      const ratio = n("debt") / n("income") * 100;
      return { value: `${format(ratio)}%`, detail: "Monthly debt payments as a share of gross monthly income.", rows: [["Monthly debt payments", format(n("debt"))], ["Gross monthly income", format(n("income"))]] };
    }
    case "gpa-cgpa": {
      const grades = v.grades.split(",").map((entry) => Number(entry.trim()));
      const credits = v.credits.split(",").map((entry) => Number(entry.trim()));
      if (!grades.length || grades.length !== credits.length || grades.some((grade) => !Number.isFinite(grade)) || credits.some((credit) => !Number.isFinite(credit) || credit <= 0)) {
        return { value: "—", detail: "Enter matching comma-separated grade points and credits." };
      }
      const totalCredits = credits.reduce((sum, credit) => sum + credit, 0);
      const weightedPoints = grades.reduce((sum, grade, index) => sum + grade * credits[index], 0);
      return { value: format(weightedPoints / totalCredits, 2), detail: `Credit-weighted average on the selected ${v.scale}-point scale.`, rows: [["Courses included", format(grades.length, 0)], ["Total credits", format(totalCredits, 2)], ["Weighted grade points", format(weightedPoints, 2)]] };
    }
    case "final-grade": {
      const weight = n("weight") / 100;
      const needed = (n("target") - n("current") * (1 - weight)) / weight;
      if (needed > 100) return { value: `${format(needed)}%`, detail: "The target is not reachable through the final exam alone.", rows: [["Maximum possible course grade", format(n("current") * (1 - weight) + 100 * weight) + "%"]] };
      if (needed <= 0) return { value: "0%", detail: "The target is already met under these inputs; zero on the final would still meet it." };
      return { value: `${format(needed)}%`, detail: "Minimum final exam score needed to reach the target.", rows: [["Current course grade", `${format(n("current"))}%`], ["Final exam weight", `${format(n("weight"))}%`], ["Target course grade", `${format(n("target"))}%`]] };
    }
    case "fraction": {
      let numeratorA: bigint;
      let denominatorA: bigint;
      let numeratorB: bigint;
      let denominatorB: bigint;
      try {
        numeratorA = BigInt(v.a);
        denominatorA = BigInt(v.b);
        numeratorB = BigInt(v.c);
        denominatorB = BigInt(v.d);
      } catch {
        return { value: "—", detail: "Enter whole-number numerators and denominators." };
      }
      let numerator: bigint;
      let denominator: bigint;
      switch (v.operation) {
        case "subtract": numerator = numeratorA * denominatorB - numeratorB * denominatorA; denominator = denominatorA * denominatorB; break;
        case "multiply": numerator = numeratorA * numeratorB; denominator = denominatorA * denominatorB; break;
        case "divide": numerator = numeratorA * denominatorB; denominator = denominatorA * numeratorB; break;
        default: numerator = numeratorA * denominatorB + numeratorB * denominatorA; denominator = denominatorA * denominatorB;
      }
      if (denominator === 0n) return { value: "—", detail: "A denominator cannot be zero." };
      const fraction = simplifiedFraction(numerator, denominator);
      const decimal = Number(numerator) / Number(denominator);
      return { value: fraction, detail: "Simplified fraction.", rows: [["Decimal equivalent", format(decimal, 8)], ["Operation", v.operation]] };
    }
    case "ratio": {
      let a: bigint;
      let b: bigint;
      try {
        a = BigInt(v.a);
        b = BigInt(v.b);
      } catch {
        return { value: "—", detail: "Enter positive whole numbers." };
      }
      if (a <= 0n || b <= 0n) return { value: "—", detail: "Both ratio parts must be positive." };
      const divisor = greatestCommonDivisor(a, b);
      return { value: `${a / divisor}:${b / divisor}`, detail: "Simplified ratio in lowest terms." };
    }
    case "age": {
      const [year, month, day] = v.birth.split("-").map(Number);
      const [endYear, endMonth, endDay] = v.at.split("-").map(Number);
      let years = endYear - year;
      let months = endMonth - month;
      let days = endDay - day;
      if (days < 0) { months--; days += new Date(endYear, endMonth - 1, 0).getDate(); }
      if (months < 0) { years--; months += 12; }
      const valid = new Date(year, month - 1, day) <= new Date(endYear, endMonth - 1, endDay);
      return { value: valid ? `${years} years` : "Invalid date range", detail: valid ? `${months} months and ${days} days elapsed.` : "The reference date must be on or after birth.", rows: valid ? [["Completed years", String(years)], ["Calendar months", String(months)], ["Additional days", String(days)]] : [] };
    }
    case "unit-converter": {
      let output: number;
      if (v.kind === "temperature") {
        const celsius = v.from === "°F" ? (n("value") - 32) * 5 / 9 : v.from === "K" ? n("value") - 273.15 : n("value");
        output = v.to === "°F" ? celsius * 9 / 5 + 32 : v.to === "K" ? celsius + 273.15 : celsius;
      } else {
        const group = unitFactors[v.kind];
        output = group ? n("value") * group[v.from] / group[v.to] : Number.NaN;
      }
      return { value: `${format(output, 6)} ${v.to}`, detail: `${format(n("value"), 6)} ${v.from} converted to ${v.to}.` };
    }
    case "bmi": {
      const bmi = n("weight") / Math.pow(n("height") / 100, 2);
      const detail = bmi < 18.5 ? "Below the general adult reference range" : bmi < 25 ? "Within the general adult reference range" : bmi < 30 ? "Above the general adult reference range" : "In the higher adult reference range";
      return { value: format(bmi, 1), detail, rows: [["Weight", `${format(n("weight"))} kg`], ["Height", `${format(n("height"))} cm`]] };
    }
    case "paint": {
      const area = n("width") * n("height") * n("walls") - n("openings");
      const litres = area * n("coats") / n("coverage");
      return { value: `${format(litres)} L`, detail: "Estimated paint volume for the entered surfaces.", rows: [["Paintable area", `${format(area)} m²`], ["Coats", format(n("coats"), 0)], ["Coverage", `${format(n("coverage"))} m²/L`]] };
    }
    case "ohms-law": {
      const voltage = n("voltage");
      const resistance = n("resistance");
      const current = voltage / resistance;
      return { value: `${format(current, 4)} A`, detail: "Calculated current", rows: [["Voltage", `${format(voltage)} V`], ["Resistance", `${format(resistance)} Ω`], ["Power", `${format(voltage * current)} W`]] };
    }
    case "profit-margin": {
      const profit = n("revenue") - n("cost");
      return { value: `${format(profit / n("revenue") * 100)}%`, detail: "Gross profit margin", rows: [["Gross profit", format(profit)], ["Revenue", format(n("revenue"))], ["Cost", format(n("cost"))]] };
    }
    default:
      return { value: "—", detail: "Enter values to calculate." };
  }
}

function isValidDate(value: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  return date.getUTCFullYear() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCDate() === Number(match[3]);
}

function parseList(value: string): number[] {
  return value.split(",").map((part) => Number(part.trim()));
}

export function validateCalculatorInput(slug: string, values: Record<string, string>): string | null {
  const calc = calcs.find((item) => item.slug === slug);
  if (!calc) return "This calculator is not available.";
  const activeFields = slug === "percentage"
    ? calc.fields.filter((field) => values.mode === "change" ? ["mode", "original", "newValue"].includes(field.name) : ["mode", "rate", "whole"].includes(field.name))
    : calc.fields;
  for (const field of activeFields) {
    const value = values[field.name] ?? "";
    if (field.unit?.startsWith("select:") || field.unit === "text") continue;
    if (field.unit === "date") {
      if (!isValidDate(value)) return `Enter a valid ${field.label.toLowerCase()}.`;
    } else if (value.trim() === "" || !Number.isFinite(Number(value))) {
      return `Enter a valid ${field.label.toLowerCase()}.`;
    }
  }
  const number = (key: string) => Number(values[key]);
  const nonNegative = (key: string, label: string) => number(key) < 0 ? `${label} cannot be negative.` : null;
  const positive = (key: string, label: string) => number(key) <= 0 ? `${label} must be greater than zero.` : null;
  const firstError = (...errors: (string | null)[]) => errors.find((error): error is string => error !== null) ?? null;

  switch (slug) {
    case "percentage":
      return values.mode === "change" && number("original") === 0 ? "Original value must be non-zero to calculate percentage change." : null;
    case "compound-interest":
      return firstError(positive("principal", "Starting principal"), nonNegative("rate", "Interest rate"), positive("years", "Time period"));
    case "simple-interest":
      return firstError(positive("principal", "Starting principal"), nonNegative("rate", "Interest rate"), nonNegative("years", "Time period"));
    case "roi":
      return firstError(positive("cost", "Investment cost"), nonNegative("ending", "Ending value"));
    case "cagr":
      return firstError(positive("start", "Starting value"), positive("ending", "Ending value"), positive("years", "Time period"));
    case "savings-growth":
      return firstError(nonNegative("principal", "Starting balance"), nonNegative("monthly", "Monthly deposit"), nonNegative("rate", "Interest rate"), positive("years", "Time period"));
    case "savings-goal":
      return firstError(nonNegative("goal", "Savings target"), nonNegative("principal", "Current balance"), nonNegative("rate", "Interest rate"), positive("years", "Time to save"));
    case "loan-emi":
    case "loan-amortization": {
      const baseError = firstError(positive("principal", "Loan amount"), nonNegative("rate", "Interest rate"), positive("years", "Loan term"));
      if (baseError) return baseError;
      if (slug === "loan-amortization" && number("years") > 50) return "Loan term cannot exceed 50 years for a displayed amortization schedule.";
      if ((number("years") * 12) % 1 !== 0) return "Loan term must convert to a whole number of monthly payments.";
      return null;
    }
    case "dti":
      return firstError(nonNegative("debt", "Monthly debt payments"), positive("income", "Gross monthly income"));
    case "gpa-cgpa": {
      const grades = parseList(values.grades);
      const credits = parseList(values.credits);
      const scale = number("scale");
      if (grades.some((grade) => !Number.isFinite(grade)) || credits.some((credit) => !Number.isFinite(credit))) return "Enter comma-separated numbers for grades and credits.";
      if (grades.length === 0 || grades.length > 30 || credits.length !== grades.length) return "Enter the same number of grade points and credit values (1–30 courses).";
      if (grades.some((grade) => grade < 0 || grade > scale)) return `Each grade point must be from 0 to ${format(scale, 0)} on the selected scale.`;
      if (credits.some((credit) => credit <= 0)) return "Each course credit value must be greater than zero.";
      return null;
    }
    case "final-grade":
      if (number("current") < 0 || number("current") > 100 || number("target") < 0 || number("target") > 100) return "Current and target grades must be between 0 and 100%.";
      if (number("weight") <= 0 || number("weight") > 100) return "Final exam weight must be greater than 0% and no more than 100%.";
      return null;
    case "fraction":
      for (const key of ["a", "b", "c", "d"]) {
        if (!/^-?\d{1,15}$/.test(values[key])) return "Enter whole numbers with up to 15 digits for each numerator and denominator.";
      }
      if (number("b") === 0 || number("d") === 0) return "Fraction denominators cannot be zero.";
      if (values.operation === "divide" && number("c") === 0) return "Cannot divide by a fraction equal to zero.";
      return null;
    case "ratio":
      if (!/^\d{1,15}$/.test(values.a) || !/^\d{1,15}$/.test(values.b) || number("a") <= 0 || number("b") <= 0) return "Enter positive whole numbers with up to 15 digits.";
      return null;
    case "age":
      if (Date.parse(`${values.birth}T00:00:00Z`) > Date.parse(`${values.at}T00:00:00Z`)) return "The reference date must be on or after birth.";
      return null;
    case "unit-converter": {
      const amount = number("value");
      if (values.kind === "temperature") {
        const minimum: Record<string, number> = { "°C": -273.15, "°F": -459.67, K: 0 };
        return amount < minimum[values.from] ? "Temperature cannot be below absolute zero." : null;
      }
      const units = unitFactors[values.kind];
      if (!units || !(values.from in units) || !(values.to in units)) return "Choose supported units for this measurement.";
      return amount < 0 ? "Value cannot be negative for this measurement." : null;
    }
    case "bmi":
      return firstError(positive("weight", "Weight"), positive("height", "Height"));
    case "paint": {
      const sizeError = firstError(positive("width", "Wall width"), positive("height", "Wall height"), positive("walls", "Number of walls"), positive("coats", "Number of coats"), positive("coverage", "Coverage"));
      if (sizeError) return sizeError;
      if (number("openings") < 0) return "Opening area cannot be negative.";
      if (number("openings") > number("width") * number("height") * number("walls")) return "Opening area cannot exceed the total wall area.";
      return null;
    }
    case "ohms-law":
      return positive("resistance", "Resistance");
    case "profit-margin":
      return firstError(positive("revenue", "Revenue"), nonNegative("cost", "Cost"));
    default:
      return null;
  }
}
