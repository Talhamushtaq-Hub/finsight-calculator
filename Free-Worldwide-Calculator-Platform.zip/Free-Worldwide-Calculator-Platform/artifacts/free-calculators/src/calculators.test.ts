import assert from "node:assert/strict";
import test from "node:test";
import { calculate, calcs, validateCalculatorInput } from "./calculators.ts";

const closeTo = (actual: string, expected: number, tolerance = 0.01) => {
  const numeric = Number.parseFloat(actual.replaceAll(",", ""));
  assert.ok(Number.isFinite(numeric), `Expected a numeric result, got "${actual}"`);
  assert.ok(Math.abs(numeric - expected) <= tolerance, `${actual} was not within ${tolerance} of ${expected}`);
};

test("published calculators have unique slugs and page content", () => {
  const slugs = calcs.map((calculator) => calculator.slug);
  assert.equal(new Set(slugs).size, slugs.length);
  for (const calculator of calcs) {
    assert.ok(calculator.title && calculator.short && calculator.formula && calculator.example);
    assert.ok(calculator.faqs.length >= 4, `${calculator.slug} needs calculator-specific FAQs`);
  }
});

test("finance formulas match worked examples and cover zero-rate cases", () => {
  assert.equal(calculate("simple-interest", { principal: "5000", rate: "4", years: "3" }).value, "600");
  assert.equal(calculate("roi", { cost: "1000", ending: "1300" }).value, "30%");
  closeTo(calculate("cagr", { start: "1000", ending: "1331", years: "3" }).value, 10);
  closeTo(calculate("savings-growth", { principal: "1000", monthly: "100", rate: "5", years: "2" }).value, 3623.53);
  closeTo(calculate("savings-growth", { principal: "500", monthly: "25", rate: "0", years: "1" }).value, 800);
  closeTo(calculate("savings-goal", { goal: "10000", principal: "2000", rate: "5", years: "3" }).value, 198.10);
  closeTo(calculate("savings-goal", { goal: "1200", principal: "0", rate: "0", years: "1" }).value, 100);
});

test("loan calculations handle zero interest and expose a complete amortization schedule", () => {
  assert.equal(calculate("loan-emi", { principal: "1200", rate: "0", years: "1" }).value, "100");
  const result = calculate("loan-amortization", { principal: "10000", rate: "6", years: "3" });
  closeTo(result.value, 304.22);
  assert.equal(result.table?.rows.length, 36);
  assert.equal(result.table?.rows.at(-1)?.at(-1), "0");
});

test("education calculators use credits and exam weight correctly", () => {
  assert.equal(calculate("gpa-cgpa", { scale: "4", grades: "4, 3", credits: "3, 3" }).value, "3.5");
  assert.equal(calculate("final-grade", { current: "82", weight: "40", target: "85" }).value, "89.5%");
  assert.match(calculate("final-grade", { current: "82", weight: "40", target: "95" }).detail, /not reachable/);
});

test("fraction and ratio math preserve exact integer results", () => {
  assert.equal(calculate("fraction", { a: "1", b: "2", c: "1", d: "3", operation: "add" }).value, "5/6");
  assert.equal(calculate("fraction", { a: "3", b: "4", c: "2", d: "3", operation: "divide" }).value, "9/8");
  assert.equal(calculate("ratio", { a: "18", b: "24" }).value, "3:4");
});

test("unit converter covers distinct unit systems and temperature", () => {
  assert.equal(calculate("unit-converter", { kind: "length", value: "1", from: "mi", to: "km" }).value, "1.609344 km");
  assert.equal(calculate("unit-converter", { kind: "temperature", value: "20", from: "°C", to: "°F" }).value, "68 °F");
  closeTo(calculate("unit-converter", { kind: "volume", value: "1", from: "US gal", to: "Imp gal" }).value, 0.832674);
  assert.equal(calculate("unit-converter", { kind: "data", value: "1", from: "GiB", to: "GB" }).value, "1.073742 GB");
});

test("validation rejects undefined, mismatched, and out-of-range calculations", () => {
  assert.match(validateCalculatorInput("percentage", { mode: "change", original: "0", newValue: "10" }) || "", /non-zero/);
  assert.match(validateCalculatorInput("loan-amortization", { principal: "1000", rate: "5", years: "51" }) || "", /50 years/);
  assert.match(validateCalculatorInput("gpa-cgpa", { scale: "4", grades: "4,3", credits: "3" }) || "", /same number/);
  assert.match(validateCalculatorInput("gpa-cgpa", { scale: "4", grades: "4,5", credits: "3,3" }) || "", /from 0 to 4/);
  assert.match(validateCalculatorInput("fraction", { a: "1", b: "0", c: "1", d: "2", operation: "add" }) || "", /denominators/);
  assert.match(validateCalculatorInput("unit-converter", { kind: "temperature", value: "-300", from: "°C", to: "°F" }) || "", /absolute zero/);
  assert.equal(validateCalculatorInput("bmi", { weight: "70", height: "175" }), null);
});
